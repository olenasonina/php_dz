<?php
$errorsize = "";
$errortype = "";
$message = "";
$success = "";
$error = false;
$uploaddir = 'uploads/';
?>
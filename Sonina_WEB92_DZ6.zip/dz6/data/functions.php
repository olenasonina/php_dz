<?php
session_start();
function register($p, $pc, $e, $n, $f, $f2) {
    if ($p === $pc) {
        check_mail($e, "Location: ../registerform.php");
        check_pass($p, "Location: ../registerform.php");
        $passHash = password_hash($p, PASSWORD_DEFAULT);
        check_hash($passHash, "Location: ../registerform.php");
        if(!$_SESSION['message']) {
            file_put($e, $passHash, $f);
            file_put($e, $n, $f2);
            header("Location: ../loginform.php");
        }
    } else {
        $_SESSION['message'] = "Passwords don't match";
        header("Location: ../registerform.php");
    }
}

function check_mail($email_address, $path) {
    $email = filter_var($email_address, FILTER_VALIDATE_EMAIL);
    if (!$email) {
        $_SESSION['message'] = "Wrong user email";
        header($path);
    }
}

function check_pass ($pass_user, $path) {
    $password = filter_var($pass_user, FILTER_DEFAULT);
    if (empty($password) || mb_strlen($password) < 10) {
        $_SESSION['message'] = "Wrong or empty user password. Password must be at least 10 characters.";
        header($path);
    }
}

function check_hash($ph, $path) {
    if (false === $ph) {
        $_SESSION['message'] = "System error occured...";
        header($path);
    }
}

function file_put($key, $value, $path) {
    $info = $key." : ".$value."; ";
    file_put_contents($path, $info,  FILE_APPEND);
}

function check_log($file, $file2, $e, $p, $path1, $path2) {
    $mail_pass = file_get($file);
    $valid_passwords = $mail_pass;
    $valid_users = array_keys($valid_passwords);
    $validated = (in_array($e, $valid_users)) && (password_verify($p, $valid_passwords[$e]));
    if ($validated) {
        $mail_name = file_get($file2);
        $nameuser = $mail_name[$e];
        $_SESSION['nameuser'] = $nameuser;
        $options = array('cost' => 11);

        if (password_needs_rehash($mail_pass[$e], PASSWORD_DEFAULT, $options)) {
            $newHash = password_hash($p, PASSWORD_DEFAULT, $options);
            $mail_pass[$e] = $newHash;
            file_put_contents($file, "");
            foreach ($mail_pass as $k => $v) {
                file_put($k, $v, $file);
            }
        }

        header($path1);
    } else {
        $_SESSION['message'] = "You are not authorized";
        header($path2);
    }
}
function file_get($f) {
    $data = file_get_contents($f);
    $accounts = explode("; ", $data);
    $array = [];
    foreach($accounts as $str) {
        list($key, $value) = explode(' : ', $str);
        $array[$key] = $value;
    }
    return $array;
}
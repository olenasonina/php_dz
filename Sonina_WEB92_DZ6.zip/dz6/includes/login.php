<?php
session_start();
include_once ("connect.php");
include_once ("../data/functions.php");
$email = $_POST['email'];
$pass = $_POST['pass'];
$error = false;

if(isset($_POST['submit'])) {
    check_mail($email, "Location: ../loginform.php");
    check_pass ($pass, "Location: ../loginform.php");
}

if(!$_SESSION['message']) {
    check_log($file, $file2, $email, $pass, "Location: ../success.php", "Location: ../loginform.php");
}

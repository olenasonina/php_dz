<?php
$file = "../data/logs.txt";
$file2 = "../data/names.txt";
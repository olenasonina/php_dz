<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOP-500 popular domain</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12">
            <table class="table table-bordered w-100 text-center">
                <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Domain</th>
                    <th scope="col">IP-address</th>
                    <th scope="col">Rank</th>
                    <th scope="col">Status</th>
                    <th scope="col">Checked at</th>
                </tr>
                </thead>
                <tbody>
                <?php include_once __DIR__."/../{$routePage}.php"?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>

<?php
if (isset($csv)) {
    require_once __DIR__ . "/csvView.php";
} else if (isset($txt)) {
    require_once __DIR__ . "/txtView.php";
} else echo "Error...";

<?php use Olena\HTTP as HTTP; ?>
<?php static $i = 0; $time_array = []; ?>
<?php foreach ($csv->domainRank as $result_key => $result): ?>
    <?php $i++; ?>
    <?php if($i <= 500): ?>
        <tr>
            <th width="5%" scope="row"><?= $i; ?></th>
            <td width="40%"><?= $result_key ?></td>
            <td width="20%"><?= HTTP\Host::getHost($result_key) ?></td>
            <td width="10%"><?= $result ?></td>
            <?php $index = HTTP\HttpClient::getCod("https://".$result_key) ?>
            <td width="10%"><?= $index['cod'] ?></td>
            <td width="15%"><?= $index['time'] ?></td>
        </tr>
    <?php endif; ?>
<?php endforeach; ?>

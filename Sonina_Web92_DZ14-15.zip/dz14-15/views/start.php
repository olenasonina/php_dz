<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TOP-500 popular domain</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12 text-center d-flex justify-content-center align-items-center flex-column" style="height: 100vh">
            <p>Choose file for reading, please:</p>
            <form action="" method="POST" class="d-flex justify-content-around w-25">
                <input type="submit" class="btn btn-info w-25" name="action" value="csv">
                <input type="submit" class="btn btn-info w-25" name="action" value="txt">
            </form>
        </div>
    </div>
</div>
</body>
</html>

<?php
namespace Olena\FR;

interface reading {
    public function readIntoArray();
}

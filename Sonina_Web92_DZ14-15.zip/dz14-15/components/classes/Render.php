<?php
namespace Olena\Go;
use Olena\FR as FR;

class Render
{
    public static function goToPage($page, array $data = []) {
        $data['routePage'] = $page;
        extract($data);
        require_once __DIR__."/../../views/layouts/mainView.php";
    }

    public static function startPage() {
        if(!isset($_POST['action'])) {
            require_once __DIR__."/../../views/start.php";
        } else {
            if($_POST['action'] === 'csv') {
                $csv = new FR\CsvReader('small_top10milliondomains.csv');
                $csv->readIntoArray();
                Render::goToPage("detect", $data = ["csv" => $csv]);
            }
            if($_POST['action'] === 'txt') {
                $txt = new FR\TxtReader('small_top10milliondomains.txt');
                $txt->readIntoArray();
                Render::goToPage("detect", $data = ["txt" => $txt]);
            }
        }
    }
}
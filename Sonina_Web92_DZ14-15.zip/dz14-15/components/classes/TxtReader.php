<?php
namespace Olena\FR;

class TxtReader extends FileReader {

    public function __construct($path)
    {
        parent::__construct($path);
    }

    public function readIntoArray() {
        foreach($this->path as $string) {
            $this->data[] = explode(";", str_replace('"', "", $string));
        }
        $this->getDataForUnic();
    }
}


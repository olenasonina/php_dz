<?php
namespace Olena\HTTP;

class Host
{
public static function getHost($ip) {
    return gethostbyname($ip);
}
}
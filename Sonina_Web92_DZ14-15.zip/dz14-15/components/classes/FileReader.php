<?php
namespace Olena\FR;

abstract class FileReader implements reading {
    protected $path;
    protected $data = [];
    public $domainRank;

    public function __construct($path)
    {
        $this->path = file(sprintf('%s/../../%s/%s', __DIR__,'data', $path));
    }

    public function getDataForUnic() {
        $test_array = [];
        foreach ($this->data as $key => $test_item) {
            $test_array[trim($key)] = trim($test_item[1]).",".trim($test_item[2]);
        }
        $unic_array = array_unique($test_array);
        $this->getTotalData($unic_array);
    }

    public function getTotalData($data)
    {
        foreach ($data as $result) {
            $domain = explode(",", $result)[0];
            $rank = explode(",", $result)[1];
            $this->domainRank[$domain] = $rank;
            arsort($this->domainRank);
        }
    }
}
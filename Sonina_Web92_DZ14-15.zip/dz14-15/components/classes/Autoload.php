<?php
require_once __DIR__."/../../config.php";

class Autoload
{
    private static $path;
    private static $component;

    public static function checkComponentInMap($map, $name)
    {
        $class = explode('\\', $name);
        $class = array_pop($class);
        if (isset($map[$class])) {
            self::$path = $map[$class];
            self::$component = $class;
        }
        include_once(self::getFilePath());
    }

    public static function getFilePath()
    {
        return sprintf("%s/../%s/%s.php", __DIR__, self::$path, self::$component);
    }

    public static function loader() {
        spl_autoload_register(function($name) {
            $map = new Map;
            Autoload::checkComponentInMap($map::$map, $name);
        });
    }
}

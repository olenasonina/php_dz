<?php

class Map {
static $map = [
    'CsvReader' => 'classes',
    'CurlConnect' => 'classes',
    'FileReader' => 'classes',
    'HttpClient' => '/classes',
    'TxtReader' => '/classes',
    'Render' => 'classes',
    'Host' => 'classes',
    'reading' => 'interfaces'
];
}


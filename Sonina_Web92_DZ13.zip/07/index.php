<?php

ini_set("display_errors", "On");
ini_set("display_startup_errors", "On");
ini_set("error_reporting", "-1");
ini_set("log_errors", "On");
ini_set("memory_limit", "50M");
set_time_limit (0);
date_default_timezone_set("Europe/Kiev");

include_once __DIR__."/init.php";

$book = new BookProduct(
    "PHP 7 for Begginers",
    "John", "Bridge",
    59.11,
    1121
); 

$cd = new CdProduct(
    "Dark Paradise",
    "Lana", "Del Ray",
    29.99,
    52
    
);

$newspaper = new NewspaperProduct(
    "Official bulletin",
    "Publishing house",
    "Lighthouse",
    10.10,
    "may of 2020"
);


echo $book->getSummaryLine();
echo "<br>";
echo $cd->getSummaryLine();
echo "<br>";
echo $newspaper->getSummaryLine();
echo "<br><br>";

echo ShopProductWriter::write($book);
echo "<br>";
echo ShopProductWriter::write($cd);
echo "<br>";
echo ShopProductWriter::write($newspaper);
echo "<br><br>";

ShopProductWriter::save($book);
echo "<br>";
ShopProductWriter::save($cd);
echo "<br>";
ShopProductWriter::save($newspaper);
echo "<br><br>";
<?php

include_once __DIR__."/components/classes/Autoload.php";

spl_autoload_register(function ($name) {
    $filePath = Autoload::getPath($name);
    include_once $filePath;
});
<?php

class ShopProductWriter
{
    private static $file;

    public static function write(ShopProduct $product)
    {
        return sprintf('%s: %s; Price: <span style="color:green">%01.2f$</span>',
            $product->title,
            $product->getAuthor(),
            $product->price
        );
    }

    public static function save(ShopProduct $product)
    {
        $object = get_class($product);
        if($object === 'BookProduct') {
            self::$file = __DIR__ . "/../../files/books.txt";
        } elseif ($object === 'CdProduct') {
            self::$file = __DIR__ . "/../../files/cds.txt";
        } elseif ($object === 'NewspaperProduct') {
            self::$file = __DIR__ . "/../../files/newspapers.txt";
        } else echo "Error";
        self::saveIntoFile(self::$file, $product->getSummaryLineForWriting());
    }

    public static function saveIntoFile($file, $info) {
        file_put_contents($file, $info,  FILE_APPEND);
    }
}
<?php

class Autoload
{
    public static function getPath($name) {
        return $filePath = sprintf("%s/%s.php", __DIR__, $name);
    }
}
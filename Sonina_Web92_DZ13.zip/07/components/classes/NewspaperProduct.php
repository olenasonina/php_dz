<?php
class NewspaperProduct extends ShopProduct
{
    public $timePeriod;

    public function __construct($title, $authorName, $authorSurName, $price, $timePeriod)
    {
        parent::__construct(
            $title, $authorName, $authorSurName, $price
        );

        $this->timePeriod = $timePeriod;
    }

    public function getSummaryLine()
    {
        $summary = parent::getSummaryLine();
        $summary .= sprintf(', <small style="color:blue;">Time period: %s</small>', $this->getTimePeriod());

        return $summary;
    }

    public function getTimePeriod()
    {
        return $this->timePeriod;
    }

    public function getSummaryLineForWriting() {
        $writeFormat = parent::getSummaryLineForWriting();
        $writeFormat .= sprintf(', Time period: %s', $this->getTimePeriod());

        return $writeFormat;
    }

}
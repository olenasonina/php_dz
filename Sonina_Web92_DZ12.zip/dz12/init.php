<?php

function autoloadClasses($name) {
    include_once __DIR__."/components/classes/".$name.".php";
//    include_once($filename);
}

function autoloadInterfaces($name) {
    include_once __DIR__."/components/interfaces/".$name.".php";
//    include_once($filename);
}

function autoloadTraits($name) {
    include_once __DIR__."/components/traits/".$name.".php";
//    include_once($filename);
}

spl_autoload_register('autoloadClasses', true);
spl_autoload_register('autoloadInterfaces', true);
spl_autoload_register('autoloadTraits', true);



<?php
interface checkFormParametres
{
    public function check_mail ($mail, $path);
    public function check_pass($pass, $path);
}

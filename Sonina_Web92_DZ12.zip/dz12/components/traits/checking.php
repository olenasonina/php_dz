<?php
trait checking
{
    public function check_mail($email_address, $path) {
        $email = filter_var($email_address, FILTER_VALIDATE_EMAIL);
        if (!$email) {
            $_SESSION['message'] = "Wrong email address.";
            require_once __DIR__."/../../{$path}";
            exit;
        }
    }
    public function check_pass ($pass_user, $path) {
        $password = filter_var($pass_user, FILTER_DEFAULT);
        if (empty($password) || mb_strlen($password) < 10) {
            $_SESSION['message'] = "Wrong or empty user password. Password must be at least 10 characters.";
            require_once __DIR__."/../../{$path}";
            exit;
        }

    }
}

<?php

class classRegister implements checkFormParametres, fileActions {
    use checking;
    use activity;
    private $passHash;
    public function __construct($p, $pc, $e, $n, $f, $f2, $path, $newpass)
    {
        if ($p === $pc) {
            $this->check_mail($e, $path);
            $this->check_pass($p, $path);
            $this->passHash = password_hash($p, PASSWORD_DEFAULT);
            $this->check_hash($this->passHash);
            if(!$_SESSION['message']) {
                $this->file_put($e, $this->passHash, $f);
                $this->file_put($e, $n, $f2);
                require_once __DIR__."/../../{$newpass}";
                exit;
            }
        } else {
            $_SESSION['message'] = "Passwords don't match";
            require_once __DIR__."/../../{$path}";
            exit;
        }
    }
    private function check_hash($ph) {
        if (false === $ph) {
            $_SESSION['message'] = "System error occured...";
            require_once __DIR__."/../../{$path}";
            exit;
        }
    }
}
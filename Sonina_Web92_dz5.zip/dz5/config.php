<?php
$errorsize = "";
$errortype = "";
$message = "";
$success = "";
$error = false;
$uploaddir = 'uploads/';
$user = $_SERVER['PHP_AUTH_USER'];
$pass = $_SERVER['PHP_AUTH_PW'];
$string = file_get_contents('users.log');
?>
<?php include_once "handler.php" ?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome-4.7.0/css/font-awesome.css">
    <title>UploadFile</title>
</head>
<body>
<form id="fileupload" action="" method="POST" enctype="multipart/form-data">
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="mt-3">
                <?php
                if (!$validated) {
                    authenticate();
                } else {
                    echo "<p style='text-align: center'>Welcome $user.</p>";
                    echo "<p style='text-align: center'>Congratulation, you are into the system.</p>";
                }
                ?>
            </div>

            <div class="bg-primary mt-3 p-3 text-center" style="color: white; font-size: 18px">
                <div class="border border-white pt-3 pb-3">
                    <i class="fa fa-cloud-upload fa-5x" aria-hidden="true"></i>
                    <p class="w-100 d-inline-block">Drop Files here</p>
<!--                    <form id="fileupload" action="" method="POST" enctype="multipart/form-data">-->
                        <input id="myfile" type="file" name="files[]" multiple />
<!--                        <input type='submit'-->
<!--                               name="submit"-->
<!--                               class="btn btn-light ml-2"-->
<!--                               value="START">-->
<!--                    </form>-->
                    <span style="color: red ; font-weight: bold"><?php echo $errorsize."<br/>".$errortype."<br/>".$message ?></span>
                    <span style="color: white; font-weight: bold"><?php echo $success ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-6 pt-5">
            <div class="settings border border-primary rounded-top">
<!--                <form id="targetsend" action="" method="POST" class="border border-primary rounded-top">-->
                    <h5 class="bg-info p-2">
                        <i class="fa fa-cogs"></i> Settings
                    </h5>
                    <div class="form-group pl-2">
                        <label>Target format:</label><br>
                        <select name="target[]" multiple>
                            <option value="bmp">BMP</option>
                            <option value="eps">EPS</option>
                            <option value="gif">GIF</option>
                            <option value="exr">HDR/EXR</option>
                            <option value="ico">ICO</option>
                            <option value="jpg">JPG</option>
                            <option value="png">PNG</option>
                            <option value="svg">SVG</option>
                            <option value="tga">TGA</option>
                            <option value="tiff">TIFF</option>
                            <option value="wbmp">WBMP</option>
                            <option value="webp">WebP</option>
                        </select>
                    </div>
                    <div class="form-group pl-2">
                        <label>Change size:</label><br>
                        <div class="row m-0">
                            <div class="col-6 p-0">
                                <label>Width:</label>
                                <div class="d-flex">
                                    <input placeholder="1 - 65000" style="width: 150px" class="form-control pr-0" name="width" type="number" min="1" max="65000" step="1">
                                    <span class="input-group-text">px</span>
                                </div>

                            </div>
                            <div class="col-6 p-0">
                                <label>Height:</label>
                                <div class="d-flex">
                                    <input placeholder="1 - 65000" style="width: 150px" class="form-control pr-0" name="height" type="number" min="1" max="65000" step="1">
                                    <div class="input-group-append">
                                        <span class="input-group-text">px</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group pl-2">
                        <label>DPI:</label>
                        <div class="d-flex">
                            <input placeholder="10 - 1200" style="width: 150px" class="form-control pr-0" name="dpi" type="number" min="10" max="1200" step="1">
                            <div class="input-group-append">
                                <span class="input-group-text">dpi</span>
                            </div>
                        </div>
                    </div>
<!--                </form>-->
            </div>
        </div>
        <div class="col-6">
            <div class="settings pt-5">
                <div class="border border-primary rounded-top">
                    <h5 class="bg-info p-2">
                        <i class="fa fa-info-circle"></i> How to resize an image?
                    </h5>
                    <ol>
                        <li>Upload the photo you want to resize.</li>
                        <li>In the drop-down menu, choose the format you want your images to be converted to.</li>
                        <li>You can also use the DPI to change the image size when it comes to printing.</li>
                        <li>Click on "Start" to resize your photo.</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="form-group pt-4">
                <input type='submit'
                        name="submit"
                        class="btn btn-primary submit-btn"
                        onclick="document.getElementById('fileupload').submit();
                                 document.getElementById('targetsend').submit()"
                        value="START">
            </div>
        </div>
    </div>
</div>
</form>
</body>
</html>
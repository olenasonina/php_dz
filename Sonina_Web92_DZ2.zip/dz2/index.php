<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sonina_DZ2</title>
</head>
<body>
<div style="display: flex; flex-direction: column">
    <?php
    include_once 'components/zadanie1.php';
    include_once 'components/zadanie2.php';
    include_once 'components/zadanie3.php';
    include_once 'components/zadanie4.php';
    include_once 'components/zadanie5.php';
    ?>
</div>
</body>
</html>

<div>
    <h3>Задача5</h3>
    <?php
    $month_temp = array(78, 60, 62, 68, 71, 68, 73, 85, 66, 64, 76, 63, 75, 76, 73, 68, 62, 73, 72, 65, 74, 62, 62, 65, 64, 68, 73, 75, 79, 73);
    $totalTemp = 0;
    $countTemp = count($month_temp);

    foreach ($month_temp as $value) {
        $totalTemp += $value;
    }
    $srTemp = round($totalTemp/$countTemp, 1);
    echo "Average temperature is $srTemp<br>";

    sort($month_temp);
    $min_month_temp = array_values(array_unique($month_temp));
    echo "<br>";
    echo "List of seven lowest temperatures is:";
    for ($i=0; $i<7; $i++) {
        echo " ".$min_month_temp[$i];
    }

    echo "<br>";

    rsort($month_temp);
    $max_month_temp = array_values(array_unique($month_temp));
    echo "<br>";
    echo "List of seven highest temperatures is:";
    for ($i=0; $i<7; $i++) {
        echo " ".$max_month_temp[$i];
    }

    ?>
</div>
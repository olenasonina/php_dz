<div>
    <h3>Задача2</h3>
    <table border = '1' align='left'>
        <?php for ($row=1; $row<=10; $row++): ?>
            <tr>
                <?php for ($col=1; $col<=10; $col++):
                     $p = $row*$col; ?>
                     <td><?= $p ?></td>
                <?php endfor; ?>
            </tr>
        <?php endfor; ?>
    </table>
</div>
<div>
    <h3>Задача3</h3>
    <table border = '1' align='left' cellpadding='3' cellspacing='0'>
        <?php for ($i=1; $i<=6; $i++): ?>
            <tr>
                <?php for ($j=1; $j<=5; $j++):
                    $p=$i*$j ?>
                    <td><?= $i."*".$j."=".$p ?></td>
                <?php endfor; ?>
            </tr>
        <?php endfor; ?>
    </table>
</div>
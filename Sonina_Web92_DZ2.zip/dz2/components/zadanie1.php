<div>
    <h3>Задача1</h3>
    <table border = '1' align='left' style='height: 100%'>
        <?php for ($row=1; $row<=8; $row++): ?>
            <tr>
                <?php for ($col=1; $col<=8; $col++): ?>
                    <?php if (($row+$col)%2==0): ?>
                        <td width='30px' height='30px'></td>
                    <?php else: ?>
                        <td width='30px' height='30px' bgcolor='black'></td>
                    <?php endif; ?>
                <?php endfor; ?>
            </tr>
        <?php endfor; ?>
    </table>
</div>
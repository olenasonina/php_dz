<?php
$to ='suckers.txt';
$redirect = 'Location: https://www.google.com/search?q';
?>
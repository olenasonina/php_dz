<?php
echo "<h3>Your message has been send successfully!</h3>"
?>
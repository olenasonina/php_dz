<div class="alert alert-info" role="alert">
    Your shoping cart is empty
</div>

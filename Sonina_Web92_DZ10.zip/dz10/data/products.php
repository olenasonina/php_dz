<?php
$products = array(
    1 => [
        'img' => "images/81+qyAiX6qL._AC_SR106,78_.jpg",
        'name' => 'Timberland',
        'manufacture' => 'Timberland',
        'price' => 200.00,
        ],
    2 => [
        'img' => "images/71aex-7DQxL._AC_SR700,525_.jpg",
        'name' => 'Low-Rider V Cut',
        'manufacture' => 'Codiac',
        'price' => 99.95
         ],
    3 => [
         'img' => "images/71khW-QAkYL._AC_SR700,525_.jpg",
         'name' => 'Cowbaby Double',
         'manufacture' => 'Roper kids',
         'price' => 43
         ]
);

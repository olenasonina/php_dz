<?php

class Map {
static $map = [
'classLogin' => 'classes',
'classRegister' => 'classes',
'checkFormParametres' => 'interfaces',
'fileActions' => 'interfaces',
'activity' => 'traits',
'checking' => 'traits'
];
}


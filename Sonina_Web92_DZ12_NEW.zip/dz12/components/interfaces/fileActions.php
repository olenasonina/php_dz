<?php
interface fileActions
{
    public function file_put($key, $value, $path);
    public function file_get($f);
}

<?php
interface checkFormParametres
{
    public function check_mail ($mail);
    public function check_pass($pass);
}

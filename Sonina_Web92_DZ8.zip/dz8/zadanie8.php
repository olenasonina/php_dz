<?php
// Применение функции к каждому элементу массива

//1. Использование функции array_walk() для одномерных массивов:

$names = array('firstname' => "Baba",
               'lastname' => "O'Riley"); // исходный одномерный массив
array_walk($names, function (&$value, $key) {  // значение $value передается по ссылке для того, чтобы изменялся массив, а не его копия
    $value = htmlentities($value, ENT_QUOTES); // htmlentities() кодирует ключевые сущности HTML и присваивает результат $value
});
foreach ($names as $name) {
    print $name."<br>";  // вывод результата
}

//2. Использование функции array_walk_recursive() для вложенных данных:

$names2 = array('firstnames' => array("Baba", "Bill"),
                'lastnames' => array("O'Riley", "O'Reilly"));
array_walk_recursive($names2, function (&$value, $key) { // обращение к вложенному массиву
    $value = htmlentities($value, ENT_QUOTES);
});
foreach ($names2 as $nametypes) {
    foreach ($nametypes as $name) {
        print $name."<br>";  // // вывод результата через 2 цикла foreach
    }
}
<?php
//Требуется связать несколько элементов с каждым ключом.

$fruits = array(); //создаем пустой массив
$fruits['red'][] = 'strawberry'; //присваиваем первое значение для ключа 'red'
$fruits['red'][] = 'apple'; //присваиваем второе значение для ключа 'red'
$fruits['yellow'][] = 'banana'; //присваиваем первое значение для ключа 'yellow'

echo "<pre>";
print_r($fruits);

//Для поочередного вывода элементов из массива используем цикл foreach:

foreach ($fruits as $color => $color_fruit) { // $color - ключ, $color_fruit - значение, которое в свою очередь является числовым массивом
    foreach ($color_fruit as $fruit) { // $fruit - это значение числового массива $color_fruit
        print "$fruit is colored $color.<br>"; // вывод фруктов и их цветов на каждой итерации циклов foreach
    }
}
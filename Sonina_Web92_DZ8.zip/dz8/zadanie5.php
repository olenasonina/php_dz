<?php
//Требуется преобразовать имеющийся массив в отформатированную строку.

$array = [
    'firstkey' => 'firstvalue',
    'secondkey' => 'secondvalue',
    'thirdkey' => 'thirdvalue'
];

//1. Построение строки в цикле:
foreach ($array as $key => $value) { // перебор массива
    $string .= ", $value"; // запись поочереди в конец массива значений
}
$string = substr($string, 2); // удаление первой запятой с пробелом, а точнее получение части строки со второго порядкого знака,
// так как первый знак "," и второй знак " " нам не нужны.

echo $string."<br>";

//2. Использование функции join():

$string2 = join(', ', $array);
echo $string2."<br>";

//3. Использование функции implode():

$string3 = implode(', ', $array);
echo $string3."<br>";

//4. Использование функции serialize() для преобразования сложных массивов в строку и использования для обратного процесса unserialize():
$string4 = serialize($array);
echo $string4."<br>";
$array2 = unserialize($string4);
echo "<pre>";
var_dump($array2);
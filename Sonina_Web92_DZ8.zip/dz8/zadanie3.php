<?php
// Требуется в цикле перебрать элементы массива и выполнить операцию с неко-
//торыми (или всеми) элементами.

//1. Для перебора массива используем цикл foreach, например:

$array = [
    'firstkey' => 'firstvalue',
    'secondkey' => 'secondvalue',
    'thirdkey' => 'thirdvalue'
];

foreach ($array as $key => $value) {
    print("This $key for that $value <br>");
}

// або:

$array2 = ['firstvalue', 'secondvalue', 'thirdvalue'];
foreach ($array2 as $value) {
    print("This array has $value <br>");
}

//2. Можно воспользовать циклом for, например:

$summ = 0;
$array3 = [2,5,6,7,8];
$size = count($array3);
for ($i=0; $i<$size; $i++) {
    $summ += $array3[$i];
}
echo $summ;

//3. можно использовать each() в сочетании с list() и while. Продемонстрирую на предыдущем примере:

$summ2 = 0;
$array4 = [2,5,6,7,8];
reset($array4); // Внутренний указатель устанавливается в начало массива
while (list($key, $value) = each ($array4)) {
    $summ2 += $array4[$key];
}
echo "<br>".$summ2;
<?php
// Требуется объединить два массива в один.

//1. Для слияния двух массивов можно использовать "+", например:

$arr1 = [
    'firstkey' => 'firstvalue',
    'secondkey' => 'secondvalue'
];

$arr2 = [
    'thirdkey' => 'thirdvalue'
];

$arr_all = $arr1 + $arr2;

echo "<pre>";
print_r($arr_all);

// однако такой способ годится только в том случае, если ключи второго массива не дублируют ключи первого массива.
// Иначе первый массив останется без изменений, а знвчения второго массива не запишутся. Например:

$arr3 = [
    'firstkey' => 'firstvalue',
    'secondkey' => 'secondvalue'
];

$arr4 = [
    'secondkey' => 'thirdvalue'
];

$arr_all2 = $arr3 + $arr4;

echo "<pre>";
print_r($arr_all2);

// Для слияния двух массивов следует пользоваться функцией array_merge().
// В этом случае, если ключи совпадают, то значение перезапишется, как мы и привыкли:

$arr5 = [
    'firstkey' => 'firstvalue',
    'secondkey' => 'secondvalue'
];

$arr6 = [
    'secondkey' => 'thirdvalue'
];

$arr_all3 = array_merge($arr5, $arr6);

echo "<pre>";
print_r($arr_all3);


// в числовом массиве  ключи перезаписываются:

$lc = array('a', 'b' => 'b'); // первый элемент имеет числовой ключ - 0,
$uc = array('A', 'b' => 'B'); // первый элемент имеет числовой ключ - 0, который перезапишется и станет 1.
// А второй элемент перезапишет второй элемент первого массива, так как совпадает ключ
$ac = array_merge($lc, $uc);
echo "<pre>";
print_r($ac);
<?php
// Требуется найти в массиве элементы, удовлетворяющие некоторому условию.

// Например, нужно найти все элементы значения которых больше 10.

// 1. Перебор массива с помощью цикла foreach:

$array = [9,25,6,32,4,87,5,2,1,96,1,4,5,85,35,6]; // начальный массив
$newArray = [];
foreach ($array as $arrayItem) {
    if ($arrayItem > 10) $newArray[] = $arrayItem;
}
echo "<pre>";
var_dump($newArray);

// 2. Использование встроенной функции array_filter():

$newArray2 = array_filter($array, function ($item) { // функция, проверяющая значения
    return $item > 10 ? 1 : 0;
});

echo "<pre>";
var_dump($newArray2);

<?php
// Требуется реализовать собственную процедуру сортировки.

// 1. Использование функции sort():
$array1 = array('IMG0.png', 'img12.png', 'img10.png', 'img2.png', 'img1.png', 'IMG3.png');
sort($array1);
echo "<pre>";
var_dump($array1); // сортирует с учетом регистр, не сохраняя ключи

// 2. Использование функции natcasesort():

natcasesort($array1);
echo "<pre>";
var_dump($array1); // сортирует без учета регистра, не сохраняя ключи, но в естественном порядке

// 3. Использование функции asort():

$array2 = array('IMG0.png', 'img12.png', 'img10.png', 'img2.png', 'img1.png', 'IMG3.png');
asort($array2);
echo "<pre>";
var_dump($array2); // сортирует с учетом регистр, сохраняя ключи

// 4. Сортировка в обратном порядке

$tests = array('test1.php', 'test10.php', 'test11.php', 'test2.php');
// Естественная сортировка в обратном порядке с использованием функции usort():
usort($tests, function ($a, $b) {
    return strnatcmp($b, $a);  // strnatcmp() - сортировка в естественном порядке, то есть как будто сортирует человек от 1 до ... по увеличению числа на 1
    // в данном случае идет перестановка в обратном порядке.
});

echo "<pre>";
var_dump($tests);
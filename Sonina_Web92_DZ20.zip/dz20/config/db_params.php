<?php

$data = [
    "db_host" => "localhost",
    "db_user" => "root",
    "db_pass" => "15081986",
    "db_table" => "windstore-learnDB"
];